import React from "react";
import { Zap } from "lucide-react";

interface QuotaWidgetProps {
  dailyRemaining: number;
  maxQuota: number;
  onReset: () => void;
}

export const QuotaWidget: React.FC<QuotaWidgetProps> = ({ dailyRemaining, maxQuota, onReset }) => {
  return (
    <div className="bg-slate-50 border-b border-slate-200 py-2 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between text-xs font-medium text-slate-500">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>系统状态: 正常</span>
          </div>
          <div className="h-3 w-px bg-slate-200" />
          <div className="flex items-center gap-2">
            <Zap size={12} className="text-amber-500" />
            <span>当前计划: <span className="text-slate-900 font-bold">免费试用</span></span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span>今日剩余额度:</span>
            <div className="flex gap-1">
              {[...Array(maxQuota)].map((_, i) => (
                <div 
                  key={i} 
                  className={`w-3 h-1.5 rounded-full transition-all ${i < dailyRemaining ? 'bg-brand-500' : 'bg-slate-200'}`} 
                />
              ))}
            </div>
            <span className="text-slate-900 font-bold ml-1">{dailyRemaining}/{maxQuota}</span>
          </div>
          <button 
            onClick={onReset}
            className="text-brand-600 hover:underline text-[10px] uppercase tracking-wider font-bold"
          >
            模拟重置
          </button>
        </div>
      </div>
    </div>
  );
};
