import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ChevronRight, 
  Clock, 
  ExternalLink, 
  Circle 
} from "lucide-react";
import { SkillNode } from "../types";

interface SkillCardProps {
  skill: SkillNode;
  index: number;
}

export const SkillCard: React.FC<SkillCardProps> = ({ skill, index }) => {
  const [isExpanded, setIsExpanded] = useState(index === 0);

  return (
    <div className="glass-card rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div 
        onClick={() => setIsExpanded(!isExpanded)}
        className="p-6 flex items-center justify-between cursor-pointer hover:bg-slate-50 transition-colors"
      >
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-bold">
            {index + 1}
          </div>
          <div>
            <h4 className="font-bold text-slate-900">{skill.title}</h4>
            <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
              <Clock size={12} /> {skill.estimatedTime}
            </p>
          </div>
        </div>
        <div className={`transition-transform duration-300 ${isExpanded ? 'rotate-90' : ''}`}>
          <ChevronRight size={20} className="text-slate-400" />
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-6 pb-6 pt-2 space-y-6">
              <p className="text-slate-600 text-sm leading-relaxed">
                {skill.description}
              </p>

              {/* Learning Steps */}
              {skill.learningSteps && skill.learningSteps.length > 0 && (
                <div className="space-y-3">
                  <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">专业学习步骤</h5>
                  <div className="space-y-2">
                    {skill.learningSteps.map((step, sIdx) => (
                      <div key={sIdx} className="flex gap-3 p-3 rounded-xl bg-brand-50/50 border border-brand-100/50">
                        <div className="w-5 h-5 rounded-full bg-brand-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                          {sIdx + 1}
                        </div>
                        <p className="text-sm text-slate-700 font-medium leading-relaxed">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Resources */}
              <div className="space-y-3">
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">推荐资源</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {skill.resources.map((resource, rIdx) => {
                    const isBili = resource.platform.toLowerCase().includes('bilibili');
                    const isYT = resource.platform.toLowerCase().includes('youtube');
                    const isCoursera = resource.platform.toLowerCase().includes('coursera');
                    
                    let platformColor = "bg-slate-50 text-slate-500";
                    if (isBili) platformColor = "bg-pink-50 text-pink-500";
                    else if (isYT) platformColor = "bg-red-50 text-red-500";
                    else if (isCoursera) platformColor = "bg-blue-50 text-blue-500";

                    return (
                      <a 
                        key={rIdx}
                        href={resource.url.startsWith('http') ? resource.url : `https://www.google.com/search?q=${encodeURIComponent(resource.platform + ' ' + resource.title)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-start gap-3 p-3 rounded-xl border border-slate-100 hover:border-brand-200 hover:bg-brand-50/30 transition-all group"
                      >
                        <div className={`p-2 rounded-lg shrink-0 ${platformColor}`}>
                          <ExternalLink size={16} />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-slate-900 truncate group-hover:text-brand-700">{resource.title}</p>
                          <p className="text-[10px] text-slate-400 font-medium uppercase mt-0.5">{resource.platform}</p>
                        </div>
                      </a>
                    );
                  })}
                </div>
              </div>

              {/* Sub Skills */}
              {skill.subSkills && skill.subSkills.length > 0 && (
                <div className="space-y-3">
                  <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider">核心知识点</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {skill.subSkills.map((sub, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-100">
                        <Circle size={12} className="text-brand-500" />
                        <span className="text-xs text-slate-700 font-medium">{sub.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
