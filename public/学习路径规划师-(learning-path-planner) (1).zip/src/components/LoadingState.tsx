import React from "react";
import { motion } from "motion/react";
import { Loader2, AlertCircle } from "lucide-react";

interface LoadingStateProps {
  loadingMessage: string;
  loadingTime: number;
}

export const LoadingState: React.FC<LoadingStateProps> = ({ loadingMessage, loadingTime }) => {
  return (
    <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-slate-200 shadow-sm">
      <div className="relative mb-8">
        <div className="absolute inset-0 bg-brand-200 rounded-full blur-2xl opacity-20 animate-pulse" />
        <Loader2 className="w-16 h-16 text-brand-600 animate-spin relative z-10" />
      </div>
      
      <h3 className="text-xl font-bold text-slate-900 mb-2">正在构建您的学习路径</h3>
      <p className="text-slate-500 mb-8 animate-pulse">{loadingMessage}</p>
      
      <div className="w-full max-w-md px-8">
        <div className="flex justify-between text-xs text-slate-400 mb-2">
          <span>正在检索实时教育资源...</span>
          <span>已耗时: {loadingTime}s</span>
        </div>
        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden mb-4">
          <motion.div 
            className="h-full bg-brand-500"
            initial={{ width: "0%" }}
            animate={{ 
              width: loadingTime < 10 ? "30%" : loadingTime < 25 ? "70%" : "95%" 
            }}
            transition={{ duration: 2 }}
          />
        </div>
        <div className="flex items-start gap-2 p-3 bg-amber-50 rounded-xl border border-amber-100">
          <AlertCircle size={14} className="text-amber-600 mt-0.5 shrink-0" />
          <p className="text-[11px] text-amber-800 leading-relaxed">
            提示：为了确保资源（B站/YouTube等）的真实有效，AI 正在进行实时联网搜索。此过程通常需要 <span className="font-bold">20-40 秒</span>，请耐心等待。
          </p>
        </div>
      </div>
    </div>
  );
};
