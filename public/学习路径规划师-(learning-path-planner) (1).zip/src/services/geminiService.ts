import { GoogleGenAI } from "@google/genai";
import { learningPathSchema, LearningPath } from "../types";

export async function generateLearningPath(goal: string, level: string, duration: string): Promise<LearningPath> {
  // Create a new instance right before the call to ensure it uses the latest API key
  // Priority: 1. AI Studio injected key, 2. Local VITE env key, 3. Fallback
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || (import.meta as any).env.VITE_GEMINI_API_KEY || "";
  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    As an expert learning consultant, create a highly detailed and structured learning path for a user.
    Goal: ${goal}
    Current Level: ${level}
    Target Duration: ${duration}

    The learning path should be broken down into major skill modules. 
    For each module:
    1. Provide a clear title and description.
    2. Estimate the time needed.
    3. Provide a "learningSteps" array containing 3-5 highly professional, actionable, and specific steps to master this module. This should demonstrate expert pedagogical structure.
    4. Recommend at least 2 HIGHLY RELEVANT and REAL resources. 
    5. CRITICAL: Use your search tool to find ACTUAL, WORKING URLs for these resources. Do not hallucinate or guess URLs.
    6. Resources can be Bilibili videos, YouTube videos, Coursera courses, or professional blogs.
    7. For Bilibili, ensure the URL is a valid video link (e.g., bilibili.com/video/BV...).
    8. If you cannot find a direct URL, provide a very specific search link (e.g., https://search.bilibili.com/all?keyword=...).
    9. Ensure the resources are DIRECTLY RELEVANT to the skill.
    10. Break it down into sub-skills.

    Ensure the path is logical, moving from fundamentals to advanced topics.
    Return the result in JSON format matching the provided schema.
  `;

  const maxRetries = 2;
  let lastError: any;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      let response;
      try {
        response = await ai.models.generateContent({
          model: "gemini-3.1-pro-preview",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: learningPathSchema as any,
            tools: [{ googleSearch: {} }],
          },
        });
      } catch (proError: any) {
        console.warn(`Attempt ${attempt + 1}: Gemini 3.1 Pro failed, falling back to Flash:`, proError);
        try {
          response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
            config: {
              responseMimeType: "application/json",
              responseSchema: learningPathSchema as any,
              tools: [{ googleSearch: {} }],
            },
          });
        } catch (flashError: any) {
          console.warn(`Attempt ${attempt + 1}: Gemini 3 Flash failed, falling back to 1.5 Flash:`, flashError);
          // Final fallback to the most widely available stable model
          response = await ai.models.generateContent({
            model: "gemini-1.5-flash",
            contents: prompt,
            config: {
              responseMimeType: "application/json",
              responseSchema: learningPathSchema as any,
            },
          });
        }
      }

      if (!response || !response.text) {
        throw new Error("AI 未返回有效内容");
      }

      // Clean the response text in case it contains markdown code blocks
      let cleanText = response.text.trim();
      if (cleanText.startsWith("```json")) {
        cleanText = cleanText.replace(/^```json/, "").replace(/```$/, "").trim();
      } else if (cleanText.startsWith("```")) {
        cleanText = cleanText.replace(/^```/, "").replace(/```$/, "").trim();
      }

      const result = JSON.parse(cleanText || "{}");
      return {
        goal,
        level,
        duration,
        skills: result.skills || [],
      };
    } catch (error: any) {
      lastError = error;
      console.error(`Attempt ${attempt + 1} failed:`, error);
      if (attempt < maxRetries - 1) {
        // Wait before retrying (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
      }
    }
  }

  throw new Error(lastError?.message || "AI 服务响应异常，请稍后再试。可能是由于网络波动或 API 暂时不可用。");
}
